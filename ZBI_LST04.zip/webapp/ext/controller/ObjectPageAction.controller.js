sap.ui.controller("ZBI_LST04.ext.controller.ObjectPageAction", {
	onAfterRendering: function() {
	
		this.getView().byId("edit").setVisible(false); 
		this.getView().byId("delete").setVisible(false); 
		
	},

	onClickActionInvoice1: function(oEvent) {
		var bindingContext = this.getView().getBindingContext();
		var path = bindingContext.getPath();
		var object = bindingContext.getModel().getProperty(path);
		var property = bindingContext.getProperty("BILL_NUM");
		var pdfUrl = "/sap/opu/odata/sap/Z_ECC_IVC_HIST_SRV/PDFdataSet('<INVOICE_NUMBER>')/$value";
		pdfUrl = pdfUrl.replace("<INVOICE_NUMBER>", property);

		window.open(pdfUrl, property, "height=800,width=600,status=no,menubar=no,toolbar=no,personalbar=no,status=no");

	}
});