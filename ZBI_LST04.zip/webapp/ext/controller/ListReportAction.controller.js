sap.ui.controller("ZBI_LST04.ext.controller.ListReportAction", {
	onInit: function() {

		var oView = this.getView();
		var oFilterBar = sap.ui.getCore().byId(oView.getId() + "--listReportFilter");
		var sModel = new sap.ui.model.json.JSONModel({
			suggetions: []
		});
		this.getView().setModel(sModel, "sModel");

		},

	onAfterRendering: function() {
		var oView = this.getView();
		var oFilterBar = sap.ui.getCore().byId(oView.getId() + "--listReportFilter");
		oFilterBar.fireSearch();
		this.ControlsArray = [];
		for (var filterItem = 0; filterItem < oFilterBar.getAllFilterItems().length; filterItem++) {
			var oMySmartFilterMatnr = oFilterBar.getAllFilterItems().find(function(oElement) {
				return oElement.getProperty("name") === oFilterBar.getAllFilterItems()[filterItem].getProperty("name");
			}).getControl();
			var filteritem = oMySmartFilterMatnr.getId();
			if( filteritem.substring(filteritem.length - 3) === "__T"){
			this.ControlsArray.push(oMySmartFilterMatnr);
			oMySmartFilterMatnr = null;
			}
		}
		
		for (var control = 0; control < this.ControlsArray.length; control++) {
			this.ControlsArray[control].setShowSuggestion(true);
			this.ControlsArray[control].attachSuggest(this._sugestionFuction, this);
		}
	
	},
	_sugestionFuction: function(oEvent) {
		var that = this;
		var oView = this.getView();
		var oFilterBar = sap.ui.getCore().byId(oView.getId() + "--listReportFilter");
		var sModel = new sap.ui.model.json.JSONModel({});
		var sTerm = oEvent.getParameter("suggestValue");
		var aFilters = [];
		var filterVal = oEvent.getSource().mBindingInfos.value.binding.sPath.split("/")[1];
		var oCurrentField = null;
		oCurrentField = oFilterBar.getAllFilterItems().find(function(oElement) {
			return oElement.getProperty("name") === filterVal;
		}).getControl();

		if (sTerm) {
			var EntitySetName = "";
			aFilters.push(new sap.ui.model.Filter(filterVal, sap.ui.model.FilterOperator.Contains, sTerm.toUpperCase()));
			var model = this.getView().getModel();
			if (filterVal.substring(filterVal.length - 3) === "__T") {
				EntitySetName = "vl" + filterVal;
			} else {
				EntitySetName = "Invoice";
			}
			model.read("/" + EntitySetName + "", {
				filters: aFilters,
				success: function(oData) {
					sModel.setProperty("/results", oData.results);
					that.getView().setModel(sModel, "sModel");
					sModel.updateBindings(true);

					that.SuggestionTemplate = new sap.ui.core.ListItem({
						key: "{sModel>" + filterVal + "}",
						text: "{sModel>" + filterVal + "}"
					});
					oCurrentField.bindAggregation("suggestionItems", {
						path: "sModel>/results",
						template: that.SuggestionTemplate
					});
				},
				error: function(error) {
					sap.m.MessageToast.show(error);
				}
			});
		}
	
	},

	onBeforeRebindTableExtension: function(oEvent) {
		var oBindingParams = oEvent.getParameter("bindingParams");
		oBindingParams.parameters = oBindingParams.parameters || {};
		var oSmartTable = oEvent.getSource();
		var oSmartFilterBar = this.byId(oSmartTable.getSmartFilterId());
		var vCategory;
		if (oSmartFilterBar instanceof sap.ui.comp.smartfilterbar.SmartFilterBar) {
			//Custom price filter
			var oCustomControl = oSmartFilterBar.getControlByKey("CustomPriceFilter");
			if (oCustomControl instanceof sap.m.ComboBox) {
				vCategory = oCustomControl.getSelectedKey();
				oBindingParams.filters.push(new sap.ui.model.Filter("BILL_NUM", "Contains", vCategory));
			}
		}
	},
	onClickActionInvoice2  : function() {
		var oTable = this.getView().byId("listReport");
		var oBusyDialog = new sap.m.BusyDialog({});
		var selectedItems = oTable.getTable().getSelectedContextPaths();
		if (selectedItems.length > 0) {
			oBusyDialog.open();
			var selectedItemArray = [];
			jQuery.each(selectedItems, function(index, sPath) {
				selectedItemArray.push(sPath.split("/")[1]);
			});
			jQuery.each(selectedItemArray, function(idx, billnum) {
				var property = billnum.split("'")[1];
				var pdfUrl = "/sap/opu/odata/sap/Z_ECC_IVC_HIST_SRV/PDFdataSet('<INVOICE_NUMBER>')/$value";
				pdfUrl = pdfUrl.replace("<INVOICE_NUMBER>", property);
				jQuery('<a/>', {
					'href': pdfUrl,
					'download': "" + property + ".pdf",
					'text': "click"
				}).hide().appendTo("body")[0].click();
			});
			jQuery.sap.delayedCall(2000, this, function() {
				oBusyDialog.close();
			});
		} else {
			sap.m.MessageToast.show("Please Select Invoices");
		}

	}

});