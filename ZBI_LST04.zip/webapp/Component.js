jQuery.sap.declare("ZBI_LST04.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ZBI_LST04.Component", {
	metadata: {
		"manifest": "json"
	}
});